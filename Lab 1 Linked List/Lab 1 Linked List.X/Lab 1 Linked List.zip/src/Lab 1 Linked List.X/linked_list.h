
/** Maximum number of characters in a list element */
#define MAX_NODE_CHARS 10

/** Maximum number of list nodes in the list */
#define MAX_LIST_SIZE 5



typedef struct list_node_t
{
    unsigned char node_number;
    unsigned char node_data[MAX_NODE_CHARS];
    struct list_node_t *next;
    struct list_node_t *prev;
} list_element, *nodeptr;



void    list_init(void);

/** <b> add_element </b> adds an element to the linked list */
nodeptr add_element(const char* value);

#ifdef DEBUG

void db_view_linked_list(void);

#endif
