#include "Main.h"
#include "linked_list.h"
#include "stddef.h" //for null

typedef enum {
    NO_ERROR, // no error
    MISSING_NULL, // no null present in string passed to linked list, or it is
                  // truncated (too long) and the null is removed
    LIST_OVERFLOW // linked list is longer than allowed by linked_list.h
} linked_list_error_codes;

static linked_list_error_codes error_code;

static list_element* top;
static list_element* current;
static list_element* previous;


static list_element* read_cursor;
static list_element* write_cursor;
static list_element* head;
static list_element* tail;
static INT16 list_size; // units in elements

char temp[MAX_NODE_CHARS];

#ifdef DEBUG

list_element db_linked_list[MAX_LIST_SIZE];

#endif

void    list_init(void)
{
    unsigned int i;
    head=(list_element*) malloc(sizeof(list_element));
    head->next=NULL;
    head->prev=NULL;
    for(i=0;i<=MAX_NODE_CHARS;i++)
    {
        head->node_data[i]='\0';
    }
    head->node_number = 0;
    tail=head;
    tail->next=NULL;
    tail->prev=NULL;
    for(i=0;i<=MAX_NODE_CHARS;i++)
    {
        tail->node_data[i]='\0';
    }
    tail->node_number = 0;

    list_size=0;
}

list_element* add_element(const char* value)
{
    INT16 current_list_size=0;
    list_element* retval=NULL;
    list_element* elem;
    UINT16 size_temp=0;
    BOOL null_check_temp=FALSE;
    struct list_node_t * previous_head_pointer;

    INT16 i;

    // Check to see if we are either adding a string without a NULL or
    // a string longer than the size of each node
    for(i=0;i<=MAX_NODE_CHARS;i++)
    {
        if (*(value+i*4)=='\0')
        {
            null_check_temp=TRUE;
        }
    }
    if (null_check_temp==FALSE)
    {
        error_code=MISSING_NULL;
    }

    if(list_size==0)
    {
        // we are creating a new linked list
        head=(list_element*) malloc(sizeof(list_element));
        head->next=(list_element*) &tail;
        head->prev=NULL;
        tail->next=NULL;
        tail->prev=(list_element*) &head;

        //Initialize the list
        for(i=0;i<=MAX_NODE_CHARS;i++)
        {
            if(*value!=NULL)
            {
                head->node_data[i]=*value++;
            }
            else
            {
                head->node_data[i]=0;
            }
        }
        head->node_number = 1;
        list_size++; 
    }
    else
    {

        //we are adding to the new linked list
        previous_head_pointer=head;
        
        head=(list_element*) malloc(sizeof(list_element));
        previous_head_pointer->prev=(list_element*) &head;
        head->next=(list_element*) &previous_head_pointer;
        head->prev=NULL;

        //Initialize the list
        for(i=0;i<=MAX_NODE_CHARS;i++)
        {
            if(*value!=NULL)
            {
                head->node_data[i]=*value++;
            }
            else
            {
                head->node_data[i]=0;
            }
        }
        head->node_number = ++list_size;
    }


    Nop();
    Nop();
    Nop();


#if 0
    // Check to see if we are adding either a string without a NULL or
    // a string longer than the size of each node
    while((*value!='\0')&&(size_temp<MAX_NODE_CHARS))
    {
        size_temp++;
        value++;
    }
    if ((size_temp==0)||(size_temp==MAX_NODE_CHARS))
    {
        retval=NULL;
    }
    else
    {
        if(current->next!=previous->next)
        {
            previous=current;
        }

        //list is empty, make a new one
        elem=(list_element*) malloc(sizeof(list_element));


        //Clear out the new malloc'ed space
        for(i=0;i<MAX_NODE_CHARS; i++)
        {
            elem->node_data[i]=0;
        }


        //Initialize the malloc'ed node
        for(i=size_temp;i>=0;i--)
        {
            elem->node_data[i]=*value--;
        }

        //initialize the new node's next pointer
        elem->next=NULL;
        
        retval=elem;

        current=elem;


        if (elem==NULL) retval=NULL; // might happen if malloc failed
        Nop();
        
    }


    if((previous->next==NULL)&&(current->next==NULL))
    {
        //A new list has begun
        elem->next=top;
    }
    else
    {
        //a list is already in place
        elem->next=current -> next;
        previous->next=elem ->next;
    }
//    elem->next=NULL;
#endif
    return retval;
}

#ifdef DEBUG

void db_view_linked_list(void)
{
    unsigned int i;
    list_element* temp;
    if(list_size>0)
    {
        for(i=0;i<list_size;i++)
        {
            db_linked_list->next=0;
            db_linked_list->prev=0;
            db_linked_list->node_data[0]=0;
            db_linked_list->node_number=0;
        }
    }
}

#endif