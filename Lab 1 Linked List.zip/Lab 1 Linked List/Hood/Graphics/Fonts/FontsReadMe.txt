
Following fonts are used by the Graphics demo.
The license for these mentioned fonts are available on one of their parent webpages.
Most fonts used are included with the distribution, except for FireFlySung and UnBatang. These font files are big, and you need to download them from websites below in order to regenerate Graphics Resource Converter resources.


Gentium:
http://scripts.sil.org/cms/scripts/page.php?site_id=nrsi&cat_id=FontDownloads

VeraMono:
http://www-old.gnome.org/fonts/#Final_Bitstream_Vera_Fonts

Jaipur:
http://ccat.sas.upenn.edu/plc/hindi/jaipur/jaipur.zip

DB ThaiText:
http://www.thai-language.com/downloads/dbtt.ttf


FireFlySung:
http://www.unifont.org/fontguide/ (Click East Asia)

UnBatang:
http://www.unifont.org/fontguide/ (Click East Asia)